const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: "*" }
});

const PORT = process.env.PORT || 3000;
const rooms = {};

io.on("connection", (socket) => {
  console.log("🔌 Connected:", socket.id);

  socket.on("joinRoom", ({ roomId, nickname }) => {
    socket.join(roomId);
    if (!rooms[roomId]) rooms[roomId] = [];
    rooms[roomId].push({ id: socket.id, nickname });

    io.to(roomId).emit("updatePlayers", rooms[roomId]);
    console.log(`👥 ${nickname} joined ${roomId}`);
  });

  socket.on("disconnect", () => {
    for (const roomId in rooms) {
      const prevCount = rooms[roomId].length;
      rooms[roomId] = rooms[roomId].filter((p) => p.id !== socket.id);
      if (rooms[roomId].length < prevCount) {
        io.to(roomId).emit("updatePlayers", rooms[roomId]);
      }
    }
    console.log("❌ Disconnected:", socket.id);
  });
});

app.get("/", (req, res) => {
  res.send("🟢 Reverse Tetris multiplayer server is running.");
});

server.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});